﻿CREATE TABLE [dbo].[UserRoles]
(
	[RoleID] INT NOT NULL PRIMARY KEY, 
    [Role] NCHAR(10) NULL
)
