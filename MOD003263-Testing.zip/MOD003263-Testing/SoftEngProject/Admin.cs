﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftEngProject
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
            loadTable();
        }
                      
        void loadTable()
        {
            string conString = Properties.Settings.Default.TemplateDBString;
            string query = Constants.sqlQuerySelUser;
            SqlConnection connection = new SqlConnection(conString);
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = command;
                DataTable dtUser = new DataTable();
                sda.Fill(dtUser);

                BindingSource newSource = new BindingSource();
                newSource.DataSource = dtUser;
                dgr_Users.DataSource = newSource;
                sda.Update(dtUser);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btn_Load_Click(object sender, EventArgs e)
        {
            loadTable();
        }

        private void btn_newUser_Click(object sender, EventArgs e)
        {
            NewUser newfrm = new NewUser();
            newfrm.Show();
        }
    }
}
