﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SoftEngProject
{
    public partial class NewUser : Form
    {
        string conString = Properties.Settings.Default.TemplateDBString;

        public NewUser()
        {
            InitializeComponent();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            add(txt_Username.Text, txt_Password.Text, cmb_Role.Text);
        }

        private void add(String Username, String Password, String Role)
        {
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                if (txt_Username.Text != "" & txt_Password.Text != "" & cmb_Role.Text != "")
                {

                    String sql = "insert into Users (Username, Password, Role) values (@txt_Username, @txt_Password, @cmb_Role)";
                    SqlCommand cmd = new SqlCommand(sql, connection);

                    cmd.Parameters.AddWithValue("@txt_Username", Username);
                    cmd.Parameters.AddWithValue("@txt_Password", Password);
                    cmd.Parameters.AddWithValue("@cmb_Role", Role);

                    connection.Open();

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        
                        MessageBox.Show("New User Inserted");
                        this.Close();
                        NewUser frm = new NewUser();
                        frm.Show();
                    }

                    connection.Close();
                    
                }
                else
                {
                    MessageBox.Show("Data Missing! You must enter text for all fields");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }   
    }
}
