﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class Form1 : Form
    {
        public string usernameData;
        public string passwordData;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            usernameData = txt_username.Text;
            passwordData = txt_password.Text;

//            DataSet dataLogin = dbConnection.getDBConnectionInstance().getDataSet(Constants.queryLoginCheck(usernameData, passwordData));
            int dataLogin = dbConnection.getDBConnectionInstance().xx(Constants.queryLoginCheck(usernameData, passwordData));
            MessageBox.Show("£ " + dataLogin);
            dbConnection dataSet = new dbConnection();
            dataSet.getDataSet();

            




            this.Hide();
            Main welcome = new Main();
            welcome.Show();
        }
    }
}
