﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginForm
{
    class Constants
    {
        //SQL QUERIES
        public static string queryLoginCheck(string username, string password)
        {
                string sqlQueryLoginCheck = "SELECT * FROM USER WHERE USERNAME ='" + username + "' AND PASSWORD ='" + password + "'";
                return sqlQueryLoginCheck;
        }
    }
}
