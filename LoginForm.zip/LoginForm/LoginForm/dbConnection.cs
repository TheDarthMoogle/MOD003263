﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace LoginForm
{
    class dbConnection
    {
        private static dbConnection _instance;

        private static string connectionStr;

        SqlConnection connectiontoDB;

        private SqlDataAdapter dataAdapter;


        public static string connection
        {
            set
            {
                connectionStr = value;
            }

        }


        public static dbConnection getDBConnectionInstance()
        {
            if(_instance == null)
            {
                _instance = new dbConnection();
            }

            return _instance;
        }


        public void openConnection()
        {
            connectiontoDB = new SqlConnection(connectionStr);

            connectiontoDB.Open();
        }

        public void closeConnection()
        {
            connectiontoDB.Close();
        }

        public void getDataSet()
        {
            throw new NotImplementedException();
        }

        public int xx(String sqlQuery)
        {
            System.Data.DataSet dataSet = getDataSet(sqlQuery);

            return dataSet.Tables[0].Rows.Count;
            
        }

        public System.Data.DataSet getDataSet(String sqlQuery)
        {
            System.Data.DataSet dataSet;

            openConnection();

            // create the dataAdapter object
            dataAdapter = new System.Data.SqlClient.SqlDataAdapter(sqlQuery, connectiontoDB);

            //create the dataSet object
            dataSet = new System.Data.DataSet();

            //fill in the dataSet with the data coming from the DB 
            dataAdapter.Fill(dataSet);



            closeConnection();
            //return the dataset
            return dataSet;
        }


    }
}
